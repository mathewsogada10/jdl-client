import axios from "axios";
export const baseUrl = "http://192.168.88.244:8000/";

export const styles = {
  fontSize: "12px"
};


